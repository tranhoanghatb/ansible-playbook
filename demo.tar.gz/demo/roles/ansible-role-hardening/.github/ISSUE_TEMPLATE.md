---
name: Lint failure
about: A lint failure issue
title: "[ACTION] Linting failed"
assignees: konstruktoid
labels: bug
---
{{ tools.context.actor }}: {{ tools.context.sha }}
